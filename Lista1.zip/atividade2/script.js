var elementos = document.getElementsByTagName("p");
for(let i = 0; i < elementos.length; i++) {
    elementos[i].innerHTML = "Olá mundo JS!";
}