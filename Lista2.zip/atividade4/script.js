function minhaFuncao () {
    document.getElementsByTagName("p")[0].innerHTML = "Olá, Seja bem vindo ao mundo JS!"
}