function minhaFuncao () {
    document.getElementById("boas-vindas").innerHTML = "Olá, Seja bem vindo ao mundo JS!"
}